export const PAGE_DESCRIPTIONS = {
  "Overview Dashboard": "A clear view of road conditions and detection activity.",
  "Live Detection": "Capture road conditions with image, video, or live camera detection.",
  "Pothole Registry": "Review recorded potholes and confirmed detection events.",
  Analytics: "Explore detection trends and road condition patterns.",
  "GIS Map": "Inspect pothole records with verified GPS coordinates.",
  "Severity Analysis": "Review recorded potholes by severity and trend.",
  "Reports and Exports": "Filter and export records from your available data.",
  "User Management": "Review account access and registered user activity.",
};

export const SEVERITY_COLORS = { low: "#16a34a", medium: "#d97706", high: "#dc2626", critical: "#7f1d1d" };
export const REFRESH_SECONDS = 5;
export const PAGE_SIZE = 25;
