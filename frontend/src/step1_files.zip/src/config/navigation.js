import {
  Activity,
  BarChart3,
  Camera,
  ClipboardList,
  FileText,
  Home,
  MapPin,
  Users,
} from "lucide-react";

// Format: [menu label, icon, URL path, internal page name]
export const USER_NAVIGATION = [
  ["Overview", Home, "/user/dashboard", "Overview Dashboard"],
  ["Report Pothole", Camera, "/user/report", "Live Detection"],
  ["My Potholes", ClipboardList, "/user/my-potholes", "Pothole Registry"],
  ["My Analytics", BarChart3, "/user/analytics", "Analytics"],
  ["My Map", MapPin, "/user/map", "GIS Map"],
  ["Severity Analysis", Activity, "/user/severity", "Severity Analysis"],
  ["Reports & Exports", FileText, "/user/reports", "Reports and Exports"],
];

export const ADMIN_NAVIGATION = [
  ["Global Overview", Home, "/admin/dashboard", "Overview Dashboard"],
  ["User Management", Users, "/admin/users", "User Management"],
  ["Pothole Management", ClipboardList, "/admin/potholes", "Pothole Registry"],
  ["Global Analytics", BarChart3, "/admin/analytics", "Analytics"],
  ["Global Map", MapPin, "/admin/map", "GIS Map"],
  ["Severity Analysis", Activity, "/admin/severity", "Severity Analysis"],
  ["Reports & Exports", FileText, "/admin/reports", "Reports and Exports"],
];
